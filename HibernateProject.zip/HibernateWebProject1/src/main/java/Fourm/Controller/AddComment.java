package Fourm.Controller;

import java.io.IOException;
import Fourm.Dao.FourmDao;
import Fourm.Model.FourmBean;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/AddComment")
public class AddComment extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html; charset=UTF-8");
        response.setCharacterEncoding("UTF-8");

        String productId = request.getParameter("productId");
        String userId = request.getParameter("userId");
        int rating = Integer.parseInt(request.getParameter("rating"));
        String comment = request.getParameter("comment");

        String message = "";
        FourmBean fourmBean = new FourmBean();

        if (productId == null || productId.isEmpty() ||
            userId == null || userId.isEmpty() ||
            comment == null || comment.isEmpty()) {
            message = "錯誤：所有欄位都是必填的";
            request.setAttribute("message", message);
            request.getRequestDispatcher("/jsp/GetAllComments.jsp").forward(request, response);
            return;
        }

        FourmDao fourmDAO = null;
        try {
            fourmDAO = new FourmDao();
            int reviewId = fourmDAO.addComment(productId, userId, rating, comment);

            if (reviewId > 0) {
                message = "成功：評論已成功添加";
                fourmBean.setProductId(productId);
                fourmBean.setUserId(userId);
                fourmBean.setRating(rating);
                fourmBean.setComment(comment);
                fourmBean.setReviewId(String.valueOf(reviewId));
            } else {
                message = "錯誤：無法添加評論";
            }
        } catch (Exception e) {
            e.printStackTrace();
            message = "錯誤：" + e.getMessage();
        } finally {
            if (fourmDAO != null) {
                fourmDAO.close();
            }
        }

        request.setAttribute("message", message);
        request.setAttribute("fourmBean", fourmBean);
        request.getRequestDispatcher("/GetAllComments").forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
}
