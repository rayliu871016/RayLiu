package Fourm.Controller;

import java.io.IOException;
import Fourm.Dao.FourmDao;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/DeleteComments")
public class DeleteComments extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html; charset=UTF-8");
        response.setCharacterEncoding("UTF-8");

        String[] deleteIds = request.getParameterValues("deleteIds");

        if (deleteIds == null || deleteIds.length == 0) {
            response.getWriter().write("Error: No comments selected for deletion");
            return;
        }

        FourmDao fourmDAO = null;
        try {
            fourmDAO = new FourmDao();
            int rowsDeleted = fourmDAO.deleteComments(deleteIds);

            if (rowsDeleted > 0) {
                response.getWriter().write("成功：評論已成功刪除");
            } else {
                response.getWriter().write("錯誤：無法刪除評論");
            }

            request.getRequestDispatcher("/GetAllComments").forward(request, response);
        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().write("Error: " + e.getMessage());
        } finally {
            if (fourmDAO != null) {
                fourmDAO.close();
            }
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
}
