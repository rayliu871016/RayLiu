package Fourm.Controller;

import java.io.IOException;
import java.util.List;
import Fourm.Dao.FourmDao;
import Fourm.Model.FourmBean;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/GetAllComments")
public class GetAllComments extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html; charset=UTF-8");
        response.setCharacterEncoding("UTF-8");

        FourmDao fourmDAO = null;
        try {
            fourmDAO = new FourmDao();
            List<FourmBean> fourms = fourmDAO.getAllComments();

            request.setAttribute("forums", fourms);
            request.getRequestDispatcher("/jsp/GetAllComments.jsp").forward(request, response);
        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().write("Error: " + e.getMessage());
        } finally {
            if (fourmDAO != null) {
                fourmDAO.close();
            }
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
}
