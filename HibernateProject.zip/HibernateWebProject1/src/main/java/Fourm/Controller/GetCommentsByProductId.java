package Fourm.Controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import Fourm.Dao.FourmDao;
import Fourm.Model.FourmBean;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/GetCommentsByProductId")
public class GetCommentsByProductId extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html; charset=UTF-8");
        response.setCharacterEncoding("UTF-8");

        String productId = request.getParameter("productId");

        if (productId == null || productId.isEmpty()) {
            response.getWriter().write("Error: productId is required");
            return;
        }

        try {
            FourmDao fourmDAO = new FourmDao();
            List<FourmBean> fourms = fourmDAO.getCommentsByProductId(productId);

            request.setAttribute("fourms", fourms);
            request.getRequestDispatcher("/jsp/GetCommentsByProductId.jsp").forward(request, response);
        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().write("Error: " + e.getMessage());
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
}
