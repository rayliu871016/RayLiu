package Fourm.Controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import Fourm.Dao.FourmDao;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/UpdateComments")
public class UpdateComments extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html; charset=UTF-8");
        response.setCharacterEncoding("UTF-8");

        String reviewId = request.getParameter("reviewId");
        String productId = request.getParameter("productId");
        String userId = request.getParameter("userId");
        int rating = Integer.parseInt(request.getParameter("rating"));
        String comment = request.getParameter("comment");

        if (reviewId == null || reviewId.isEmpty() ||
            productId == null || productId.isEmpty() ||
            userId == null || userId.isEmpty() ||
            comment == null || comment.isEmpty()) {
            response.getWriter().write("Error: All fields are required");
            return;
        }

        try {
            FourmDao fourmDAO = new FourmDao();
            int rowsUpdated = fourmDAO.updateComment(reviewId, productId, userId, rating, comment);

            if (rowsUpdated > 0) {
                response.getWriter().write("成功：評論已成功更新");
            } else {
                response.getWriter().write("錯誤：無法更新評論");
            }

            request.getRequestDispatcher("/GetAllComments").forward(request, response);
        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().write("Error: " + e.getMessage());
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
}
