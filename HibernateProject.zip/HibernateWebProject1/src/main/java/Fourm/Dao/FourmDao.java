package Fourm.Dao;


import Fourm.Model.FourmBean;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import java.util.List;

public class FourmDao {
    private SessionFactory sessionFactory;

    public FourmDao() {
        sessionFactory = new Configuration().configure().buildSessionFactory();
    }

    public void close() {
        sessionFactory.close();
    }

    public int addComment(String productId, String userId, int rating, String comment) {
        Session session = sessionFactory.openSession();
        Transaction transaction = null;
        int reviewId = 0;
        
        try {
            transaction = session.beginTransaction();
            FourmBean forum = new FourmBean();
            forum.setProductId(productId);
            forum.setUserId(userId);
            forum.setRating(rating);
            forum.setComment(comment);
            session.save(forum);
            transaction.commit();
            reviewId = Integer.parseInt(forum.getReviewId());
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        } finally {
            session.close();
        }
        
        return reviewId;
    }

    public int deleteComments(String[] reviewIds) {
        Session session = sessionFactory.openSession();
        Transaction transaction = null;
        int deletedCount = 0;
        
        try {
            transaction = session.beginTransaction();
            for (String reviewId : reviewIds) {
                FourmBean forum = session.get(FourmBean.class, reviewId);
                if (forum != null) {
                    session.delete(forum);
                    deletedCount++;
                }
            }
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        } finally {
            session.close();
        }
        
        return deletedCount;
    }

    public List<FourmBean> getAllComments() {
        Session session = sessionFactory.openSession();
        List<FourmBean> forums = null;
        
        try {
            forums = session.createQuery("FROM ForumBean", FourmBean.class).list();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            session.close();
        }
        
        return forums;
    }

    public List<FourmBean> getCommentsByProductId(String productId) {
        Session session = sessionFactory.openSession();
        List<FourmBean> forums = null;
        
        try {
            forums = session.createQuery("FROM ForumBean WHERE productId LIKE :productId", FourmBean.class)
                    .setParameter("productId", "%" + productId + "%")
                    .list();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            session.close();
        }
        
        return forums;
    }

    public int updateComment(String reviewId, String productId, String userId, int rating, String comment) {
        Session session = sessionFactory.openSession();
        Transaction transaction = null;
        int updated = 0;
        
        try {
            transaction = session.beginTransaction();
            FourmBean forum = session.get(FourmBean.class, reviewId);
            if (forum != null) {
                forum.setProductId(productId);
                forum.setUserId(userId);
                forum.setRating(rating);
                forum.setComment(comment);
                session.update(forum);
                transaction.commit();
                updated = 1;
            }
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        } finally {
            session.close();
        }
        
        return updated;
    }
}