package Fourm.Model;

import java.io.Serializable;
import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;


@Entity
@Table(name = "Fourm")
public class FourmBean implements Serializable {
    private static final long serialVersionUID = 1L;
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "reviewid")
    private String reviewId;

    @Column(name = "productid", nullable = false)
    private String productId;

    @Column(name = "userid", nullable = false)
    private String userId;

    @Column(name = "rating", nullable = false)
    private Integer rating;  

    @Column(name = "comment")
    private String comment;

    @Column(name = "timestamp")
    private String timestamp;
    
    public String getReviewId() {
        return reviewId;
    }

    public void setReviewId(String reviewId) {
        this.reviewId = reviewId;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public Integer getRating() {  
        return rating;
    }

    public void setRating(Integer rating) {  
        this.rating = rating;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    @Override
    public String toString() {
        return "ForumBean{" +
                "reviewId='" + reviewId + '\'' +
                ", productId='" + productId + '\'' +
                ", userId='" + userId + '\'' +
                ", rating=" + rating +
                ", comment='" + comment + '\'' +
                ", timestamp='" + timestamp + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        FourmBean forumBean = (FourmBean) o;
        return Objects.equals(reviewId, forumBean.reviewId) &&
                Objects.equals(productId, forumBean.productId) &&
                Objects.equals(userId, forumBean.userId) &&
                Objects.equals(rating, forumBean.rating) &&
                Objects.equals(comment, forumBean.comment) &&
                Objects.equals(timestamp, forumBean.timestamp);
    }

    @Override
    public int hashCode() {
        return Objects.hash(reviewId, productId, userId, rating, comment, timestamp);
    }
}