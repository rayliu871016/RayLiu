package tw.rayliu.model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity @Table(name ="house")
public class House implements Serializable {
	
	private static final long serialVersionUID = 2466417130823396041L;
	@Id @Column(name = "HOUSEID")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int houseid;
	public int getHouseid() {
		return houseid;
	}
	
	@Column(name = "HOUSENAME")
	private String housename;
	
	public House() {
	}
	
	public House(String housename) {
		super();
		this.housename = housename;
	}

	public void setHouseid(int houseid) {
		this.houseid = houseid;
	}
	public String getHousename() {
		return housename;
	}
	public void setHousename(String housename) {
		this.housename = housename;
	}
	public House(int houseid, String housename) {
		super();
		this.houseid = houseid;
		this.housename = housename;
	}

}
