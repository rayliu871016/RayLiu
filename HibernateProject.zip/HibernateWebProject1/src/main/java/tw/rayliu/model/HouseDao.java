package tw.rayliu.model;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.query.Query;

public class HouseDao implements IHouseDao {

	private Session session;

	public HouseDao(Session session) {
		this.session = session;
	}
	
	@Override   //若打錯字會提醒
	public House findById(int id ) {
		return session.get(House.class, id);
	}
	
	@Override
	public List<House> findAll() {
		Query<House> query = session.createQuery("from House", House.class);
		return query.list();
	}

	@Override
	public House insert(House insertBean) {
		 session.persist(insertBean);
		 return insertBean;
	}

	@Override
	public House update(House updateBean) {
		House resultBean = session.get(House.class, updateBean.getHouseid());
		if(resultBean!= null) {
			resultBean.setHousename(updateBean.getHousename());
//			session.update(updateBean);
//			session.flush();
		}
		return resultBean;
	}

	@Override
	public boolean deleteById(int id) {
		House deleteBean = session.get(House.class, id);
		if(deleteBean!=null) {
			session.remove(deleteBean);
			session.flush();
			return true;
		}
		return false;
	}

}
