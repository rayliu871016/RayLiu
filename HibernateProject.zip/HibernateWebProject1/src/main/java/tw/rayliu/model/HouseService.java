package tw.rayliu.model;

import java.util.List;

import org.hibernate.Session;

public class HouseService implements IHouseService {
	
	private HouseDao hDao;

	public HouseService(Session session) {
		hDao = new HouseDao(session);
	}

	@Override
	public House findById(int id) {

		return hDao.findById(id);
	}

	@Override
	public List<House> findAll() {
		
		return hDao.findAll();
	}

	@Override
	public House insert(House insertBean) {
		
		return hDao.insert(insertBean);
	}

	@Override
	public House update(House updateBean) {
		return hDao.update(updateBean);
	}

	@Override
	public boolean deleteById(int id) {
		return hDao.deleteById(id);
	}

}
