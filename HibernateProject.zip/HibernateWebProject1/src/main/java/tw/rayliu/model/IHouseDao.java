package tw.rayliu.model;

import java.util.List;

public interface IHouseDao {
	public House findById(int id);
	public List<House> findAll();
	public House insert(House insertBean);
	public House update(House updateBean);
	public boolean deleteById(int id);
}
